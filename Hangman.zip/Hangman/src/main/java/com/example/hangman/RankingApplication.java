package com.example.hangman;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;


public class RankingApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        String word = WordGiver.getWord(1);
        System.out.println("Word: " + word);

        SaveScore.saveScore("Anna", 150);
        SaveScore.saveScore("Ben", 250);
        SaveScore.saveScore("Furkan", 1000);

        FXMLLoader loader = new FXMLLoader(getClass().getResource("ranking-view.fxml"));
        Scene scene = new Scene(loader.load(), 500, 600);
        stage.setScene(scene);stage.setTitle("Ranking");
        stage.show();
    }

    public static void main(String[] args) {
        Application.launch(RankingApplication.class, args);
    }
}