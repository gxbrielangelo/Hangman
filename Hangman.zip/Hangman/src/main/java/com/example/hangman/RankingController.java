package com.example.hangman;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class RankingController {
    @FXML
    private TableView<PlayerScore> rankingTable;

    @FXML
    private TableColumn<PlayerScore, String> playerColumn;

    @FXML
    private TableColumn<PlayerScore, Integer> scoreColumn;

    @FXML
    public void initialize() {
        playerColumn.setCellValueFactory(new PropertyValueFactory<>("player"));
        scoreColumn.setCellValueFactory(new PropertyValueFactory<>("score"));

        List<String> rankingStrings = GetRanking.getRanking();

        ObservableList<PlayerScore> data = FXCollections.observableArrayList();

        for (String entry : rankingStrings) {
            String[] parts = entry.split(" ");
            if (parts.length == 2) {
                try {
                    String player = parts[0];
                    int score = Integer.parseInt(parts[1]);
                    data.add(new PlayerScore(player, score));
                } catch (NumberFormatException ignored) { }
            }
        }

        rankingTable.setItems(data);
    }

    public static class PlayerScore {
        private final String player;
        private final Integer score;

        public PlayerScore(String player, Integer score) {
            this.player = player;
            this.score = score;
        }

        public String getPlayer() {
            return player;
        }

        public Integer getScore() {
            return score;
        }
    }
}