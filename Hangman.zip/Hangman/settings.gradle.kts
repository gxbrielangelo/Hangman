rootProject.name = "Hangman"
